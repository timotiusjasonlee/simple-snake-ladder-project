package Main;

import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class Main {
	Vector<Data> vecData = new Vector<Data>();
	Data A;

	Scanner scan = new Scanner(System.in);
	Random rand = new Random();
	int choose,diceroll,diceroll2,diceroll3,ladders,olda=0,oldb=0,oldc=0,newa=0,newb=0,newc=0;
	String name1,name2,name3,first,second,third;
	public Main() {
		
		
			do {
			System.out.println("SNAKE LADDERS GAME");
			System.out.println("==================");
			System.out.println("1. Two Player");
			System.out.println("2. Three Player");
			System.out.println("3. Exit Game");
			do {
				try {
					System.out.println("Please Choose Gamemode: ");
					choose=scan.nextInt();
				}catch (Exception e) {
					choose=0;
					scan.nextLine();
				}
			}while(choose < 1 || choose >3);
			
			
			switch(choose) {
			case 1:
				
				
				System.out.println("Welcome to the two player Snake Ladder Game!!");
				System.out.println("Press Enter to start");scan.nextLine();scan.nextLine();
				System.out.println("\n\n\n\n\n\n");
				
				System.out.println("Enter Player 1 Name!:");
				name1=scan.nextLine();
				System.out.println("Enter Player 2 Name!:");
				name2=scan.nextLine();
				System.out.println("Press enter to determine the player Turn!!");
				scan.nextLine();
				while(diceroll == diceroll2) {
				diceroll=rand.nextInt(7);
				if (diceroll==0){          
					  diceroll = diceroll+1;
					}
				diceroll2=rand.nextInt(7);
				if (diceroll2==0){          
					  diceroll2 = diceroll2+1;
					}
				}
				System.out.println(name1+" get dice value of "+diceroll);
				System.out.println(name2+" get dice value of "+diceroll2);
				if(diceroll > diceroll2) {
					System.out.println(name1+" Will go first!");
					first=name1;
					second=name2;
					third="No Player";
				}else {
					System.out.println(name2+" Will go first!");
					first=name2;
					second=name1;
					third="No Player";
				}
			
				for(int i=1;i<26;i++) {
					
					System.out.println("Player "+ first +" Turn! Press Enter to roll the dice !");scan.nextLine();
					
					diceroll=rand.nextInt(7);
					if (diceroll==0){          
						  diceroll = diceroll+1;
						}
					System.out.println("old position: "+ olda);
					newa = olda + diceroll;	
					System.out.println("dice : " + diceroll);
					checkPenalty();
					System.out.println("new position: " + newa);
					System.out.println("Press Enter to continue to second player...");scan.nextLine();
				
					System.out.println("\n\n\n\n");
					
					
					System.out.println("Player "+ second +" Turn! Press Enter to roll the dice !");scan.nextLine();
					diceroll2=rand.nextInt(7);
					if (diceroll2==0){          
						  diceroll2 = diceroll2+1;
						}
					System.out.println("old position: "+ oldb);
					newb = oldb + diceroll2;
					System.out.println("dice : " + diceroll2);
					checkPenalty();
					System.out.println("new position: " + newb);
					System.out.println("Press Enter to continue to first player...");scan.nextLine();
					A= new Data (i,olda,diceroll,newa,oldb,diceroll2,newb,0,0,0);
					vecData.add(A);
					System.out.println("\n\n\n\n");
					printData();
					System.out.println("\n\n\n\n");
					olda=newa;
					oldb=newb;
					if (newa == 100|| newb ==100) {
						break;
					}
				}
				System.out.println("Game Over!");
				if(newa>newb) {
					System.out.println("The Winner is: Player "+ first +"!");
					System.out.println("\\( ^o^ )//");
					System.out.println("Press enter to return to Main Menu!");scan.nextLine();
				}else {
					System.out.println("The Winner is: Player "+ second +"!");
					System.out.println("\\( ^o^ )//");
					System.out.println("Press enter to return to Main Menu!");scan.nextLine();
				}
				vecData.removeAll(vecData);
				olda=0;
				oldb=0;
				newa=0;
				newb=0;
				break;
				
				
			case 2:
				System.out.println("Welcome to the three player Snake Ladder Game!!");
				System.out.println("Press Enter to start");scan.nextLine();scan.nextLine();
				System.out.println("\n\n\n\n\n\n");
				
				System.out.println("Enter Player 1 Name!:");
				name1=scan.nextLine();
				System.out.println("Enter Player 2 Name!:");
				name2=scan.nextLine();
				System.out.println("Enter Player 3 Name!:");
				name3=scan.nextLine();
				System.out.println("Press enter to determine the player Turn!!");
				scan.nextLine();
				while(diceroll == diceroll2|| diceroll== diceroll3 || diceroll2==diceroll3) {
				diceroll=rand.nextInt(7);
				if (diceroll==0){          
					  diceroll = diceroll+1;
					}
				diceroll2=rand.nextInt(7);
				if (diceroll2==0){          
					  diceroll2 = diceroll2+1;
					}
				diceroll3=rand.nextInt(7);
				if (diceroll3==0){          
					  diceroll3 = diceroll3+1;
					}
				}
				System.out.println(name1+" get dice value of "+diceroll);
				System.out.println(name2+" get dice value of "+diceroll2);
				System.out.println(name3+" get dice value of "+diceroll3);
				if(diceroll<diceroll2 && diceroll2<diceroll3) {
					System.out.println(name3+" Will go first!");
					System.out.println(name2+" Will go second!");
					System.out.println(name1+" Will go third!");
					first=name3;
					second=name2;
					third=name1;
					System.out.println("\\( ^o^ )//");
				}else if(diceroll<diceroll3 && diceroll3<diceroll2) {
					System.out.println(name2+" Will go first!");
					System.out.println(name3+" Will go second!");
					System.out.println(name1+" Will go third!");
					first=name2;
					second=name3;
					third=name1;
					System.out.println("\\( ^o^ )//");
				}else if(diceroll2<diceroll && diceroll<diceroll3) {
					System.out.println(name3+" Will go first!");
					System.out.println(name1+" Will go second!");
					System.out.println(name2+" Will go third!");
					first=name3;
					second=name1;
					third=name2;
					System.out.println("\\( ^o^ )//");
				}else if(diceroll2<diceroll3 && diceroll3<diceroll) {
					System.out.println(name1+" Will go first!");
					System.out.println(name3+" Will go second!");
					System.out.println(name2+" Will go third!");
					first=name1;
					second=name3;
					third=name2;
					System.out.println("\\( ^o^ )//");
				}else if(diceroll3<diceroll2 && diceroll2<diceroll) {
					System.out.println(name1+" Will go first!");
					System.out.println(name2+" Will go second!");
					System.out.println(name3+" Will go third!");
					first=name1;
					second=name2;
					third=name3;
					System.out.println("\\( ^o^ )//");
				}else if(diceroll3<diceroll && diceroll<diceroll2) {
					System.out.println(name2+" Will go first!");
					System.out.println(name1+" Will go second!");
					System.out.println(name3+" Will go third!");
					first=name2;
					second=name1;
					third=name3;
					System.out.println("\\( ^o^ )//");
				}
				
				for(int i=1;i<26;i++) {
					System.out.println("Player "+ first +" Turn! Press Enter to roll the dice !");scan.nextLine();
					diceroll=rand.nextInt(7);
					if (diceroll==0){          
						  diceroll = diceroll+1;
						}
					System.out.println("old position: "+ olda);
					newa = olda + diceroll;	
					System.out.println("dice : " + diceroll);
					checkPenalty();
					System.out.println("new position: " + newa);
					System.out.println("Press Enter to continue to second player...");scan.nextLine();
					System.out.println("\n\n\n\n");
					
					
					System.out.println("Player "+ second +" Turn! Press Enter to roll the dice !");scan.nextLine();
					diceroll2=rand.nextInt(7);
					if (diceroll2==0){          
						  diceroll2 = diceroll2+1;
						}
					System.out.println("old position: "+ oldb);
					newb = oldb + diceroll2;
					System.out.println("dice : " + diceroll2);
					checkPenalty();
					System.out.println("new position: " + newb);
					System.out.println("Press Enter to continue to third player...");scan.nextLine();
					System.out.println("\n\n\n\n");
					
					System.out.println("Player "+ third +" Turn! Press Enter to roll the dice !");scan.nextLine();
					diceroll3=rand.nextInt(7);
					if (diceroll3==0){          
						  diceroll3 = diceroll3+1;
						}
					System.out.println("old position: "+ oldc);
					newc = oldc + diceroll3;
					System.out.println("dice : " + diceroll3);
					checkPenalty();
					System.out.println("new position: " + newc);
					System.out.println("Press Enter to continue to first player...");scan.nextLine();
					A= new Data (i,olda,diceroll,newa,oldb,diceroll2,newb,oldc,diceroll3,newc);
					vecData.add(A);
					System.out.println("\n\n\n\n");
					printData2();
					System.out.println("\n\n\n\n");
					olda=newa;
					oldb=newb;
					oldc=newc;
					if (newa==100 || newb == 100 || newc == 100) {
						break;
					}
				}
				System.out.println("Game Over!");
				if(newa<newb && newb<newc) {
					System.out.println("Player "+ third +" is the winner!!!");
					System.out.println("Player "+ second +" came out Second!!!");
					System.out.println("Player "+ first + " came out Third!!!");
					System.out.println("\\( ^o^ )//");
				}else if(newa<newc && newc<newb) {
					System.out.println("Player "+ second +" is the winner!!!");
					System.out.println("Player "+ third +" came out Second!!!");
					System.out.println("Player "+ first + " came out Third!!!");
					System.out.println("\\( ^o^ )//");
				}else if(newb<newa && newa<newc) {
					System.out.println("Player "+ third +" is the winner!!!");
					System.out.println("Player "+ first +" came out Second!!!");
					System.out.println("Player "+ second + " came out Third!!!");
					System.out.println("\\( ^o^ )//");
				}else if(newb<newc && newc<newa) {
					System.out.println("Player "+ first +" is the winner!!!");
					System.out.println("Player "+ third +" came out Second!!!");
					System.out.println("Player "+ second + " came out Third!!!");
					System.out.println("\\( ^o^ )//");
				}else if(newc<newb && newb<newa) {
					System.out.println("Player "+ first +" is the winner!!!");
					System.out.println("Player "+ second +" came out Second!!!");
					System.out.println("Player "+ third + " came out Third!!!");
					System.out.println("\\( ^o^ )//");
				}else if(newc<newa && newa<newb) {
					System.out.println("Player "+ second +" is the winner!!!");
					System.out.println("Player "+ first +" came out Second!!!");
					System.out.println("Player "+ third + " came out Third!!!");
					System.out.println("\\( ^o^ )//");
				}else if(newa==newb) {
					System.out.println("its a Tie between "+ first +"and "+ second);
					System.out.println("Player "+ first +" is the winner!!!");
					System.out.println("Player "+ second +" came out Second!!!");
					System.out.println("Player "+ third + " came out Third!!!");
					System.out.println("\\( ^o^ )//");
				}else if(newa==newc) {
					System.out.println("its a Tie between "+ first +"and "+ third);
					System.out.println("Player "+ first +" is the winner!!!");
					System.out.println("Player "+ third +" came out Second!!!");
					System.out.println("Player "+ second + " came out Third!!!");
					System.out.println("\\( ^o^ )//");
				}else if(newb==newc) {
					System.out.println("its a Tie between "+ second +"and "+ third);
					System.out.println("Player "+ second +" is the winner!!!");
					System.out.println("Player "+ third +" came out Second!!!");
					System.out.println("Player "+ first + " came out Third!!!");
					System.out.println("\\( ^o^ )//");
				}
				vecData.removeAll(vecData);
				olda=0;
				oldb=0;
				oldc=0;
				newa=0;
				newb=0;
				newc=0;
				break;
				
			}
			
			
				
			}while(choose!=3);
			
			
		}
	
private void printData() {
		
		
		System.out.println("===================================================================================");
		System.out.printf(" Round |        %-16s|        %-16s|        %-16s|\n",first,second,third);
		System.out.println("       |  Old  |  Dice  |  New  |  Old  |  Dice  |  New  |  Old  |  Dice  |  New  |");
		System.out.println("===================================================================================");
		for (Data A : vecData) {
			System.out.printf("%-7d|",A.getI());
			System.out.printf("%-7d|",A.getOld());
			System.out.printf("%-8d|",A.getDice());
			System.out.printf("%-7d|",A.getNext());
			System.out.printf("%-7d|",A.getOld2());
			System.out.printf("%-8d|",A.getDice2());
			System.out.printf("%-7d|\n",A.getNext2());
		}
}

	
private void printData2() {
	
	
		System.out.println("===================================================================================");
		System.out.printf(" Round |        %-16s|        %-16s|        %-16s|\n",first,second,third);
		System.out.println("       |  Old  |  Dice  |  New  |  Old  |  Dice  |  New  |  Old  |  Dice  |  New  |");
		System.out.println("===================================================================================");
		for (Data A : vecData) {
			System.out.printf("%-7d|",A.getI());
			System.out.printf("%-7d|",A.getOld());
			System.out.printf("%-8d|",A.getDice());
			System.out.printf("%-7d|",A.getNext());
			System.out.printf("%-7d|",A.getOld2());
			System.out.printf("%-8d|",A.getDice2());
			System.out.printf("%-7d|",A.getNext2());
			System.out.printf("%-7d|",A.getOld3());
			System.out.printf("%-8d|",A.getDice3());
			System.out.printf("%-7d|\n",A.getNext3());
	
			}		
	}
		
		
	private void checkPenalty() {
		if(newa == 13) {
			newa = 7;
			System.out.println("OMG you snake!(/o_o)/ went down from 13 to step "+ newa);
		} else if(newb == 13) {
			newb = 7;
			System.out.println("OMG you snake!(/o_o)/ went down from 13 to step "+ newb);
		}else if(newc == 13) {
			newc = 7;
			System.out.println("OMG you snake!(/o_o)/ went down from 13 to step "+ newc);
		}else if(newa == 25) {
			newa = 40;
			System.out.println("Ladder! , finally!($_$) went up from 25 to step " + newa);
		}else if(newb == 25) {
			newb = 40;
			System.out.println("Ladder! , finally!($_$) went up from 25 to step " + newb);
		}else if(newc == 25) {
			newc = 40;
			System.out.println("Ladder! , finally!($_$) went up from 25 to step " + newc);
		}else if(newa == 50) {
			newa = 38;
			System.out.println("OMG you snake!(/o_o)/ went down from 50 to step "+ newa);
		}else if(newb == 50) {
			newb = 38;
			System.out.println("OMG you snake!(/o_o)/ went down from 50 to step "+ newb);
		}else if(newc == 50) {
			newc = 38;
			System.out.println("OMG you snake!(/o_o)/ went down from 50 to step "+ newc);
		}else if(newa == 63) {
			newa = 78;
			System.out.println("Ladder! , finally!($_$) went up from 63 to step " + newa);
		}else if(newb == 63) {
			newb = 78;
			System.out.println("Ladder! , finally!($_$) went up from 63 to step " + newb);
		}else if(newc == 63) {
			newc = 78;
			System.out.println("Ladder! , finally!($_$) went up from 63 to step " + newc);
		}else if(newa == 83) {
			newa = 97;
			System.out.println("Ladder! , finally!($_$) went up from 83 to step " + newa);
		}else if(newb == 83) {
			newb = 97;
			System.out.println("Ladder! , finally!($_$) went up from 83 to step " + newb);
		}else if(newc == 83) {
			newc = 97;
			System.out.println("Ladder! , finally!($_$) went up from 83 to step " + newc);
		}else if(newa == 95) {
			newa = 76;
			System.out.println("OMG you snake!(/o_o)/ went down from 95 to step "+ newa);
		}else if(newb == 95) {
			newb = 76;
			System.out.println("OMG you snake!(/o_o)/ went down from 95 to step "+ newb);
		}else if(newc == 95) {
			newc = 76;
			System.out.println("OMG you snake!(/o_o)/ went down from 95 to step "+ newc);
		}else if(newa > 100) {
			newa = 100-(newa-100);
			System.out.println("Oopss you went too far over 100, going back to "+ newa);
		}else if(newb > 100) {
			newb = 100-(newb-100);
			System.out.println("Oopss you went too far over 100, going back to "+ newb);
		}else if(newc > 100) {
			newc = 100-(newc-100);
			System.out.println("Oopss you went too far over 100, going back to "+ newc);
		}
	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
