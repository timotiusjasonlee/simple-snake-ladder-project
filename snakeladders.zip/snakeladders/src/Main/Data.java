package Main;

public class Data {

	private int i;
	private int old;
	private int dice;
	private int next;
	private int old2;
	private int dice2;
	private int next2;
	private int old3;
	private int dice3;
	private int next3;
	public Data(int i, int old, int dice, int next, int old2, int dice2, int next2, int old3, int dice3, int next3) {
		super();
		this.i = i;
		this.old = old;
		this.dice = dice;
		this.next = next;
		this.old2 = old2;
		this.dice2 = dice2;
		this.next2 = next2;
		this.old3 = old3;
		this.dice3 = dice3;
		this.next3 = next3;
	}
	public int getI() {
		return i;
	}
	public void setI(int i) {
		this.i = i;
	}
	public int getOld() {
		return old;
	}
	public void setOld(int old) {
		this.old = old;
	}
	public int getDice() {
		return dice;
	}
	public void setDice(int dice) {
		this.dice = dice;
	}
	public int getNext() {
		return next;
	}
	public void setNext(int next) {
		this.next = next;
	}
	public int getOld2() {
		return old2;
	}
	public void setOld2(int old2) {
		this.old2 = old2;
	}
	public int getDice2() {
		return dice2;
	}
	public void setDice2(int dice2) {
		this.dice2 = dice2;
	}
	public int getNext2() {
		return next2;
	}
	public void setNext2(int next2) {
		this.next2 = next2;
	}
	public int getOld3() {
		return old3;
	}
	public void setOld3(int old3) {
		this.old3 = old3;
	}
	public int getDice3() {
		return dice3;
	}
	public void setDice3(int dice3) {
		this.dice3 = dice3;
	}
	public int getNext3() {
		return next3;
	}
	public void setNext3(int next3) {
		this.next3 = next3;
	}
	
}
